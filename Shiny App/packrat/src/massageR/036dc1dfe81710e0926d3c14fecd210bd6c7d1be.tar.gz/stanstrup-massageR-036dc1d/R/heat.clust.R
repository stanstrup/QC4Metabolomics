##' Prepare dendrograms for gplots' heatmap.2.
##' 
##' This function will prepare dendrograms for the heatmap.2 function (gplots).
##' The type of scaling can be adjusted and is performed before dendrogram
##' calculations (as opposed to native heatmap.2), reordering can be turned
##' on/off and distance and clustering functions can be customized.
##' 
##' 
##' @param x Numeric matrix of the values to be plotted.
##' @param scaledim character indicating if the values should be centered and
##' scaled in either the row direction or the column direction, or none.
##' @param zlim Reassign the extremes within the scaled data: zlim=c(-3,3).
##' @param zlim_select Select when to apply zlim. For the dendrogram
##' calculations and/or for the output data.
##' @param reorder Switch on/off dendrogram reordering for row and column.
##' @param scalefun Function to do the data scaling.
##' @param distfun Function used to compute the distance (dissimilarity)
##' between both rows and columns.
##' @param hclustfun Function used to compute the hierarchical clustering when
##' Rowv or Colv are not dendrograms.
##' @return A list with the scaled data ($data), row ($Rowv) and column ($Colv)
##' dendrograms.
##' @author Original function by Thomas W. Leja. Extended by Jan Stanstrup,
##' \email{stanstrup@@gmail.com}.
##' @references
##' http://stackoverflow.com/questions/17924828/differences-in-heatmap-clustering-defaults-in-r-heatplot-versus-heatmap-2
##' @export
##' @examples
##' 
##' library(massageR)
##' library(gplots)
##' library(RColorBrewer)
##' 
##' #scalefun <- BioMark:::scalefun("auto")
##' scalefun <- scale
##' 
##' distfun <- function(x) as.dist(1-cor(t(x)))
##' #distfun <- function(x) dist(x,method="canberra")
##' 
##' hclustfun <- function(x) hclust(x, method="complete")
##' 
##' 
##' x <- as.matrix(mtcars)
##' z <- heat.clust(x,
##'                 scaledim = "column",
##'                 zlim = c(-3,3),
##'                 zlim_select = c("dend","outdata"),
##'                 reorder  = c("column","row"),
##'                 distfun  = distfun, 
##'                 hclustfun= hclustfun,
##'                 scalefun = scalefun)
##' 
##' 
##' heatmap.2(z$data,
##'           Rowv=z$Rowv, 
##'           Colv=z$Colv,
##'           trace="none",
##'           scale="none",
##'           symbreaks = TRUE,
##'           col=rev(colorRampPalette(brewer.pal(10, "RdBu"))(256))
##'           )
##'           
##' @importFrom stats as.dendrogram as.dist cor hclust
##'

heat.clust <- function(x, 
                       scaledim = "column", 
                       zlim=c(-3,3), 
                       zlim_select = c("dend","outdata"), 
                       reorder=c("column","row"),
                       scalefun = scale,
                       distfun = function(x) as.dist(1-cor(t(x))),
                       hclustfun = function(x) hclust(x, method="complete")
) {
  
  z <- x
  
  # scaling
  if ("row" %in% scaledim)    z <- t(scalefun(t(z)))
  if ("column" %in% scaledim) z <- scalefun(z)
  
  
  # dendrogram
  z_dend <- z
  
  if ("dend" %in% zlim_select) {
    z_dend <- pmin(pmax(z_dend, zlim[1]), zlim[2])
  }
  
  hcl_row <- as.dendrogram(hclustfun(distfun(z_dend)))
  hcl_col <- as.dendrogram(hclustfun(distfun(t(z_dend))))
  
  
  if (("row" %in% reorder)    | isTRUE(reorder)){
    ro      <-  rowMeans(z_dend, na.rm = T)
    hcl_row <-  reorder(hcl_row,ro)
  }
  
  if (("column" %in% reorder) | isTRUE(reorder)){
    co      <-  colMeans(z_dend, na.rm = T)
    hcl_col <-  reorder(hcl_col,co)
  }
  
  
  
  # zlim outdata
  if ("outdata" %in% zlim_select) {
    z <- pmin(pmax(z, zlim[1]), zlim[2])
  }
  
  
  
  out <- list(
    data=z, 
    Rowv=hcl_row, 
    Colv=hcl_col
  )
  
  return(out)
}
