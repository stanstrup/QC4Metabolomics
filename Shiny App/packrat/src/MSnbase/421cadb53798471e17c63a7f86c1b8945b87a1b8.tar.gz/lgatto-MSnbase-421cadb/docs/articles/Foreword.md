# Foreword {-}

[*MSnbase*](http://bioconductor.org/packages/MSnbase) is under active
development; current functionality is evolving and new features will be
added. This software is free and open-source software.  If you use it,
please support the project by citing it in publications:

> Laurent Gatto and Kathryn S. Lilley. *MSnbase - an R/Bioconductor
> package for isobaric tagged mass spectrometry data visualization,
> processing and quantitation.* Bioinformatics 28, 288-289 (2011).

