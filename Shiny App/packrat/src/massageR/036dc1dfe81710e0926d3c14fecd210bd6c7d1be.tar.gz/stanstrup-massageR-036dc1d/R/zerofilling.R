##' @rdname rep_na
##' @export
##' 

half.min    <- function(x){
  if(all(is.nan(x))) return(NaN)
  if(all(is.na(x))) return(NA)
  
  out <- min(x, na.rm = TRUE)/2
  return(out)
}

##' @rdname rep_na
##' @export
##' 
##' @importFrom stats runif
##' 

rand.to.min <- function(x){
  if(all(is.nan(x))) return(NaN)
  if(all(is.na(x))) return(NA)
  
  out <- runif(1, min=0, max=min(x, na.rm = TRUE))
  return(out)
}


##' Replacement of NA values
##' 
##' Column-wise replacement of NA values based on non-NA data.
##' 
##' 
##' @aliases rep_na rand.to.min half.min
##' @param x Input values to calculate replacement values.
##' @param mat Matrix or data.frame where each column will be treated
##' seperately.
##' @param zero.as.na If TRUE zero values are considered NA values.
##' @param rep.FUN Function to calculate replacement data. The function is
##' invoked once per missing value. \code{\link{half.min}} will replace by half
##' the minimum value. \code{\link{rand.to.min}} will replace by a random value
##' between zero and the minimum non-NA value.
##' @return A matrix with NA values replaced.
##' @author Jan Stanstrup, \email{stanstrup@@gmail.com}
##' @export
##' 

rep_na <- function(mat,zero.as.na=TRUE,rep.FUN=half.min) {
  
  mat_new <- mat
  
  if(zero.as.na) {
    mat_new[mat_new==0] <- NA
  }
  
  
  mat_new <- apply(mat_new,2,function(x) {
    out <- x  
    to_rep <- is.na(out)
    out[to_rep] <- replicate(   sum(to_rep)  ,  rep.FUN(out)   )
    return(as.numeric(out))
  })
  
  rownames(mat_new) <- rownames(mat)
  colnames(mat_new) <- colnames(mat)
  
  return(mat_new)
}
