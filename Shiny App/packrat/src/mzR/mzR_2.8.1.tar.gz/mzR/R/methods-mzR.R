setMethod("fileName",
          signature="mzR",
          function(object) return(object@fileName))
