#' Find then index of the first median value
#'
#' @param x numeric vector 
#'
#' @return Integer scalar
#' 
#' @importFrom stats median
#' 
#' @export
#'

which.median <- function(x){
    which.min(abs(x - median(x)))
}

