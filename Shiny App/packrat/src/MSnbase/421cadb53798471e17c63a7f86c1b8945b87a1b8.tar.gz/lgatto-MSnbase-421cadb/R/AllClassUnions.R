setClassUnion("mzIDClasses", c("mzID", "mzIDCollection"))
setClassUnion("logicalOrNumeric", c("logical", "numeric"))
