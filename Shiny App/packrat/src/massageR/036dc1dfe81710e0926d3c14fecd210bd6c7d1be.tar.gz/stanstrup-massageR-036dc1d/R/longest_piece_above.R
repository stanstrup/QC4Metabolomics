


#' Longest interval where X is more than Y
#'
#' Find the lastest continuous number of values in X here X>Y.
#'
#' @param X Numeric vector to test
#' @param Y Cut off
#'
#' @return integer count
#' 
#' @export
#' 
##' @importFrom dplyr %>%
##' 
#' @examples 
#' longest_piece_above(c(10,4,5,2,12,30,13,41,2,5,3,0), 10)

longest_piece_above <- function(X, Y){
    
    . <- NULL # make build check happy
    
    present <-  ifelse(X>Y,1,0) %>% 
                replace(1, 0) %>% 
                replace(2, 1) %>% 
                replace(.,length(.), 0)
    
    longest_piece <- max(which(diff(present) == -1) - which(diff(present) == 1))
    
    return(longest_piece)
}
