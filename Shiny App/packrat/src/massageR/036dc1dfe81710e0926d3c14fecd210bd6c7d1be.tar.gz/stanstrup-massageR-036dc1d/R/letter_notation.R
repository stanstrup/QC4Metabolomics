#' Title
#'
#' @param mat Symmetrical logical matrix indicating pairs
#'
#' @return List of group indeces
#' 
#' @importFrom igraph maximal.cliques graph.data.frame simplify
#' 
#' @export
#'

loc_mat_2_group_idx <- function(mat) {
    n <- nrow(mat)
    rownames(mat) <- 1:n # change row names
    colnames(mat) <- 1:n # change column names
    
    
    same <- which(mat)
    g2 <- data.frame(N1 = ((same - 1) %% n) + 1, N2 = ((same - 1) %/% n) + 1)
    g2 <- g2[order(g2[[1]]), ]
    g3 <- simplify(graph.data.frame(g2, directed = FALSE))
    cliq <- maximal.cliques(g3)
    
    return(cliq)
}



##' @rdname diff_mat2letter_not
##' @param lower Lower bound of confidence intervals.
##' @param upper Upper bound of confidence intervals.
##' @export
##' 

edges2diff_mat <- function(lower,upper){
    
    n <- length(lower)
    g <- outer(lower, upper,"-")
    g <- !(g<0)
    g <- g + t(g) # not necessary, but make matrix symmetric
    g <- g!=1
    rownames(g) <- 1:n # change row names
    colnames(g) <- 1:n # change column names
    
    return(g)
}



##' Letter notation for overlapping confidence intervals.
##' 
##' Letter notation for overlapping confidence intervals familiar in multiple
##' comparisons testing. edges2diff.mat turns upper and lower bounds of
##' confidence intervals into a logical matrix indicating which entries
##' overlap. diff.mat2letter.not creates the letter notation.
##' 
##' 
##' @aliases diff_mat2letter_not edges2diff_mat
##' @param g Symmetrical logical matrix indicating groups which should have the same letter notation.
##' @return Character vector with the letter notation.
##' @author Original code by "Marc in the box" and modified by Jan Stanstrup,
##' \email{stanstrup@@gmail.com}.
##' @references
##' http://menugget.blogspot.it/2014/05/automated-determination-of-distribution.html
##' 
##' http://stackoverflow.com/questions/27293770/compact-letter-display-from-logical-matrix/27296818
##' @export
##' @examples
##' 
##' 
##' test_data <- data.frame(    mean = c(1.48, 1.59, 1.81,1.94),
##'                             CI_lower = c(1.29,1.38,1.54, 1.62),
##'                             CI_upper = c(1.56,1.84, 2.3, 2.59)
##'                         )
##' 
##' 
##' g <- edges2diff_mat(test_data$CI_lower, test_data$CI_upper)
##' letter_notation <- diff_mat2letter_not(g)
##' letter_notation
##' 
##' 

diff_mat2letter_not <- function(g){
 
  n <- nrow(g)
  cliq <- loc_mat_2_group_idx(g)
  
  # Reorder by level order - Solution from "MrFlick" ()
  ml<-max(sapply(cliq, length))
  cliq2 <- lapply(cliq, as.numeric) 
  reord <- do.call(order, data.frame(
    do.call(rbind, 
            lapply(cliq2, function(x) c(sort(x), rep.int(0, ml-length(x))))
    )
  ))
  cliq <- cliq[reord]
  cliq
  
  # Generate labels to  factor levels
  lab.txt <- vector(mode="list", n) # empty list
  lab <- letters[seq(cliq)] # clique labels
  for(i in seq(cliq)){ # loop to concatenate clique labels
    for(j in cliq[[i]]){
      lab.txt[[j]] <- paste0(lab.txt[[j]], lab[i])
    }
  }
  
  
  
  
  return(unlist(lab.txt))
  
}
