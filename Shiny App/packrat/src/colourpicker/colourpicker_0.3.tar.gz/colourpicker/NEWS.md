# colourpicker 0.3

2016-12-05

- Added an awesome `plotHelper()` gadget+addin that makes it easy to pick colours in a plot and see in real time the updated plot as you choose new colours (#1)
- Added keyboard shortcuts for `colourPicker()` (left/right arrows to navigate the colours, 1-9 to select a colour, spacebar to add a colour...)
- don't error out if a HEX value containing alpha transparency is passed to a `colourInput()` (#4 - thanks @ddiez)

# colourpicker 0.2.1

2016-10-31

- Slight changes to colour picker gadget UI

# colourpicker 0.2

2016-09-06

- Fix vignette source to have an output (CRAN reminded me to do this) 

# colourpicker 0.1.1

2016-08-15

- upgrade to newer version of JS library that fixed bugs with new jquery
- add `runExample()` function to run the example shiny app


# colourpicker 0.1

2016-08-11

- initial version (mostly copied over from `shinyjs` package)
