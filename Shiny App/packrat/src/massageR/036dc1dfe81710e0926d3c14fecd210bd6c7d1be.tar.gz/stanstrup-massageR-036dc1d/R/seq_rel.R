#' Sequence generation of relative interval sizes
#'
#' @param from,to The starting and (maximal) end values of the sequence.
#' @param by Relative increment of the sequence.
#' @param length.out Desired length of the sequence. A non-negative integer.
#'
#' @author Tommi Suvitaival & Jan Stanstrup.
#'
#' @return Numeric vector.
#' @export
#'
#' @examples 
#' # Generate sequence from 100 to 1500 with 30 ppm intervals
#' seq <- seq_rel(from = 100, to = 1500, by = 30/1E6)

seq_rel <- function(from, to, by, length.out) {
    
    # N == number of intervals
    
    case1 <- !missing(from) & !missing(to) & !missing(by) &  missing(length.out)
    case2 <- !missing(from) & !missing(to) &  missing(by) & !missing(length.out)
    
    if(!case1 & !case2)
    stop('You need to supply either "from, to and by" or "from, to and length.out"')
    
    # seq(from, to, by =)
    if (case1) {
        N   <- (log10(to) - log10(from)) / (log10(1 + by))
        N   <- floor(N)
        seq <- ((1 + by) ^ (0:(N - 1)))  *  from
        return(seq)
    }
    
    # seq(from, to, length.out =)
    if (case2) {
        N   <- length.out - 1
        by  <- (to / from) ^ (1 / N) - 1
        seq <- ((1 + by) ^ (0:(N - 0)))  *  from
        return(seq)
    }
}
