   read_abatch <- function(...) .Call("read_abatch", ..., PACKAGE="affyio")
   read_abatch_stddev <- function(...) .Call("read_abatch_stddev", ..., PACKAGE="affyio")
